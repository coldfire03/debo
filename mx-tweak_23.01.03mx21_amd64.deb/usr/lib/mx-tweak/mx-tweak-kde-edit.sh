#!/bin/bash

editKDEglobal()
{
	echo "$1"
}


main()
{
$CMD1
}

CMD1="$1"
main

exit 0
